import jwt from "jsonwebtoken";
import { Employee } from "../models/employeeModel.js";
import { Employer } from "../models/employerModel.js";
export const isAuthenticated = async (req, res, next) => {
  try {
    const { token } = req.cookies;
    if (!token) {
      return res.status(401).json({ message: "User not found, Login first!" });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await Employee.findById(decoded._id);
    // console.log(decoded._id)
    
    if (req.user) {
      
      return next();
    } else {
      req.user = await Employer.findById(decoded._id);
    }
    next();
  } catch (error) {
    return res
      .status(500)
      .json(req.cookies );
  }
};
