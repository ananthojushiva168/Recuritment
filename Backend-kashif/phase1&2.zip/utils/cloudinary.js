// const cloudinary = require("cloudinary").v2;
import cloudinary from "cloudinary";

cloudinary.config({
  
});

export { cloudinary };

// module.exports = cloudinary
