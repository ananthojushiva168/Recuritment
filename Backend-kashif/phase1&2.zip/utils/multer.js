import  multer  from "multer";
import path from "path";
// const multer = require("multer");
// const path = require("path");

//! --- UPLOAD IMAGE WITH MULTER --- >
export const uploadImage = multer({
  storage: multer.diskStorage({}),
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    if (ext !== ".jpg" && ext !== ".jpeg" && ext !== ".png") {
      cb(new Error("File type is not supported"), false);
      return;
    }
    cb(null, true);
  },
});

//! --- UPLOAD BANNER IMAGE WITH MULTER --- >
export const uploadBanner = multer({
  storage: multer.diskStorage({}),
  bannerfile: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    if (ext !== ".jpg" && ext !== ".jpeg" && ext !== ".png") {
      cb(new Error("File type is not supported"), false);
      return;
    }
    cb(null, true);
  },
});

//! --- UPLOAD FILE WITH MULTER -->
export const uploadFile = multer({
  storage: multer.diskStorage({}),
  // filename: (req, file, cb) => {
  //   const pdffile = cb(null, Date.now() + "-" + file.originalname);
    // if (pdffile.file.mimetype.split("/")[1] === "pdf") {
    //   cb(null, true);
    // } else {
    //   cb(new Error("Not a PDF File!!"), false);
    // }
  // },
 
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(pdf)$/)) {
      return cb(
        new Error(
          // "only upload files with jpg, jpeg, png, pdf, doc, docx, xslx, xls format."
          "File type is not supported"
        )
      );
    }
    cb(undefined, true); // continue with upload
  },
  limits: {
    fileSize: 2000000, // max file size 2MB = 2000000 bytes
  },
});



// module.exports = {
//   uploadImage,
//   uploadFile,
// };
