import { Employee } from "../models/employeeModel.js";
import { sendMail } from "../utils/sendMail.js";
import otpgenerator from "otp-generator";
import { sendToken } from "../utils/sendToken.js";
import cloudinary from "cloudinary";

//? Employee Signup controller
export const register = async (req, res) => {
  try {
    const { full_name, email, password } = req.body;

    let employee = await Employee.findOne({ email });

    //* Checking user has already exists or not with same Email
    if (employee) {
      return res.status(400).json({
        success: false,
        message: `Employee already exists with ${email}`,
      });
    }

    //@ Generating OTP
    const otp = otpgenerator.generate(6, {
      digits: true,
      upperCaseAlphabets: false,
      lowerCaseAlphabets: false,
      specialChars: false,
    });

    //* Creating new User
    employee = await Employee.create({
      full_name,
      email,
      password,
      otp,
      otp_expiry: new Date(Date.now() + process.env.OTP_EXPIRE * 60 * 1000),
    });

    let subject = ["first Verify your account", "Email Verification code"];
    let html = employee;
    await sendMail(email, subject, html);

    //@Token Generator
    const token = employee.generateToken();
    const options = {
      httpOnly: true,
      expires: new Date(
        Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
      ),
    };
    res
      .status(200)
      .cookie("otpToken", token, options)
      .json({
        success: true,
        message: `OTP sent to : ${email}, please verify your email first`,
      });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
        
    });
  }
};

//@EMPLOYEE LOGIN
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res
        .status(400)
        .json({ success: false, message: "Please enter all fields" });
    }

    //* Checking if user has verified or not
    const isVerified = await Employee.findOne({ email });
    // console.log(isVerified.email_verified);
    if (!isVerified.email_verified) {
      return res.status(400).json({
        success: false,
        message: "Your Email has not been verified, first verify your email id",
      });
    }
    // * Checking if user has registered or not
    let employee = await Employee.findOne({ email }).select("+password");
    if (!employee) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid Email or Password" });
    }
    const isMatch = await employee.comparePassword(password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid Email or Password" });
    }
    // const token = employee.generateToken();
    // const options = {
    //   httpOnly: true,
    //   expires: new Date(
    //     Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
    //   ),
    // };
    // res.status(200).cookie("token", token, options).json({
    //   success: true,
    //   message: `Logged In`,
    // });
    employee = await Employee.findOne({ email });
    sendToken(res, employee, 200, "Logged in successfully");
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

//@ Employee Logout
export const logout = async (req, res) => {
  try {
    return res
      .status(200)
      .cookie("token", null, { expires: new Date(Date.now()) })
      .json({ success: true, message: "Logout Successfully" });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Failed", error: error.message });
  }
};

//@ Employee image upload
export const PostImage = async (req, res) => {
  try {
    const result = await cloudinary.v2.uploader.upload(req.file.path);
    const user = await Employee.findById(req.user._id);
    let image = await user.avatar.public_id;

    if (result) {
      if (!image) {
        user.avatar.public_id = result.public_id;
        user.avatar.url = result.secure_url;
      } else {
        await cloudinary.v2.uploader.destroy(user.avatar.public_id);

        user.avatar.public_id = result.public_id;
        user.avatar.url = result.secure_url;
      }
    } else {
      res.status(400).json({ success: false, message: "Error Uploading" });
    }

    //? ---- save user ---- >
    await user.save();
    res.status(200).json(user.avatar);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
    });
  }
};

//@ Delete Image
export const DeleteImage = async (req, res) => {
  try {
    const user = await Employee.findById(req.user._id);
    await cloudinary.v2.uploader.destroy(user.avatar.public_id);

    user.avatar.public_id = "";
    user.avatar.url = "";
    await user.save();
    res.status(200).json(user.avatar);
  }
  catch (error) {
    res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
    });
  }
}
//@ ------------ POST FILE FUNCTIONALITY -------------- >
export const PostFile = async (req, res) => {
  try {
    const result = await cloudinary.v2.uploader.upload(req.file.path);
    const user = await Employee.findById(req.user._id);
    let file = await user.cv.public_id;

    if (result) {
      if (!file) {
        user.cv.public_id = result.public_id;
        user.cv.url = result.secure_url;
      } else {
        await cloudinary.v2.uploader.destroy(user.cv.public_id);

        user.cv.public_id = result.public_id;
        user.cv.url = result.secure_url;
      }
    } else {
      res.status(400).json({ success: false, message: "Error Uploading" });
    }

    //? ---- save user ---- >
    await user.save();
    res.status(200).json(user.cv);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
    });
  }
};

//@ Delete File
export const DeleteFile = async (req, res) => {
  try {
    const user = await Employee.findById(req.user._id);
    await cloudinary.v2.uploader.destroy(user.cv.public_id);

    user.cv.public_id = "";
    user.cv.url = "";
    await user.save();
    res.status(200).json(user.cv);
  }
  catch (error) {
    res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
    });
  }
}

//@ -------------- GET employee details FUNCTIONALITY ---------------- >
export const GetEmployee = async (req, res) => {
  try {
    // const id = req.params.id;
    let user = await Employee.findById(req.user._id);
    res.json(user);
  } catch (error) {
    console.log(error);
  }
};

//@ upload banner image of employee
export const bannerImage = async (req, res) => {
  try {
  
    const result = await cloudinary.v2.uploader.upload(req.file.path);
    const user = await Employee.findById(req.user._id);
    let image = await user.banner_img.public_id;

    if (result) {
      if (!image) {
        user.banner_img.public_id = result.public_id;
        user.banner_img.url = result.secure_url;
      } else {
        await cloudinary.v2.uploader.destroy(user.banner_img.public_id);

        user.banner_img.public_id = result.public_id;
        user.banner_img.url = result.secure_url;
      }
    } else {
      res.status(400).json({ success: false, message: "Error Uploading" });
    }

    //? ---- save user ---- >
    await user.save();
    res.status(200).json(user.banner_img);
  }
  catch (error) {
    res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
  });
}
};

//@ Delete Banner Image
export const DeleteBanner = async (req, res) => {
  try {
    const user = await Employee.findById(req.user._id);
    await cloudinary.v2.uploader.destroy(user.banner_img.public_id);

    user.banner_img.public_id = "";
    user.banner_img.url = "";
    await user.save();
    res.status(200).json(user.banner_img);
  }
  catch (error) {
    res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
    });
  }
}

//? Update Profile Details
export const updateMyProfile = async (req, res) => {
  try {
    const empDetails = await Employee.findByIdAndUpdate(
      { _id: req.user._id },
      req.body,
      {
        new: true,
      }
    );
    res.status(200).json(empDetails);
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
    });
  }
};

//@upload employee-education details
export const uploadEdu = async (req, res) => {
  try {
    const { university, degree, passingYear } = req.body;

    const user = await Employee.findById(req.user._id);
    user.education.push({
      university,
      degree,
      passingYear,
    });
    await user.save();
    res
      .status(200)
      .json({ user, success: true, message: "Experience added successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
//@update employee-education details
export const update = async (req, res) => {
  try {
    const id = req.params.id;
    const { university, degree, passingYear } = req.body;

    const user = await Employee.findByIdAndUpdate(req.user._id);
    var w = [];
    for (var x of user.education) {
      if (x.id == id) {
        x.university = university;
        x.degree = degree;
        x.passingYear = passingYear;
        w.push(x);
      } else {
        w.push(x);
      }
    }
    user.education = [];
    user.education = w;

    // const education_id = req.params.education_id;
    // const edufields = await Employee.findByIdAndUpdate({"education._id":req.user.education_id},
    //   {$set: {
    //     "education.$.degree":degree,
    //      "education.$.from":from,
    //      "education.$.to":to,
    //     "education.$.marks":marks
    //   }})
    await user.save();
    // await updateEdu.save();
    // console.log(user.education);
    res
      .status(200)
      .json({ success: true, message: "Education updated successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

//@ delete employee-education details
export const deleteEducation = async (req, res) => {
  try {
    const id = req.params.id;
    // console.log(id)
    const user = await Employee.updateOne(
      { _id: req.user._id },
      { $pull: { education: { _id: id } } }
    );
    if (user) {
      res.send("deleted");
    } else {
      res.send("error");
    }
  } catch (error) {
    res
      .status(500)
      .json({ success: false, error: "Failed", message: error.message });
  }
};

//@ upload employee-exp_decription details
export const uploadexp = async (req, res) => {
  try {
    const { company, duration, role } = req.body;

    const userexp = await Employee.findByIdAndUpdate(req.user._id);
    userexp.experience.push({
      company,
      duration,
      role,
    });
    await userexp.save();
    res.status(200).json({
      userexp,
      success: true,
      message: "Experience added successfully",
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

//@update employee-experience details
export const updateExp = async (req, res) => {
  try {
    const id = req.params.id;
    const { company, duration, from, to, role } = req.body;

    const user = await Employee.findByIdAndUpdate(req.user._id);
    var experience = [];
    for (var x of user.experience) {
      if (x.id == id) {
        x.company = company;
        x.duration = duration;
        x.role = role;
        experience.push(x);
      } else {
        experience.push(x);
      }
    }
    user.experience = [];
    user.experience = experience;

    await user.save();

    res
      .status(200)
      .json({ success: true, message: "Experience updated successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

//@delete employee-experience details
export const deleteExperince = async (req, res) => {
  try {
    const id = req.params.id;
    // console.log(id)
    const user = await Employee.updateOne(
      { _id: req.user._id },
      { $pull: { experience: { _id: id } } }
    );
    if (user) {
      res.send("deleted");
    } else {
      res.send("error");
    }
  } catch (error) {
    res
      .status(500)
      .json({ success: false, error: "Failed", message: error.message });
  }
};

//@DELETE EMPLOYEE
export const delProfile = async (req, res) => {
  try {
    //deleting employee profile

    const user = await Employee.findByIdAndRemove({ _id: req.user._id });

    res
      .status(200)
      .cookie("token", null, { expires: new Date(Date.now()) })
      .json({
        success: true,
        message: "Logout and Account has Deleted Successfully",
      });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Failed", error: error.message });
  }
};

//@update EXPERIENCE-DESCRIPTION FIELDS
// export const ex_desc = async (req,res)=>{
//   try{
//     const id= req.params.id;
//     const user = await Employee.Update({_id:id},{
//       $set:{
//         "exp_description.$.company":company,
//         "exp_description.$.from":from,
//         "exp_description.$.to":to,
//         "exp_description.$.role":role
//       }
//     });
//   }
//   catch(error){
//     return res
//     .status(500)
//     .json({ success: false, message: "Failed", error: error.message });
//   }

// }

//? UpdateSkills
export const updateSkills = async (req, res) => {
  try {
    const user = await Employee.findByIdAndUpdate(
      { _id: req.user._id },
      { $addToSet: { skills: req.body.skills } }
    );
    let Skills = user.skills;
    if (user) {
      res
        .status(200)
        .json({ success: true, message: "Skills Updated", Skills });
    } else {
      res.status(400).json({ message: "Error", error: error.message });
    }
  } catch (error) {
    res.status(500).json({ message: "Failed", error: error.message });
  }
};

//? Delete Skills
export const deleteSkills = async (req, res) => {
  try {
    const { item } = req.params;
    const user = await Employee.updateOne(
      { _id: req.user._id },
      { $pull: { skills: item } }
    );
    let Skills = user.skills;
    if (user) {
      res
        .status(200)
        .json({ success: true, message: `${item} has deleted`, Skills });
    } else {
      res.status(400).json({ message: "Error", error: error.message });
    }
  } catch (error) {
    res.status(500).json({ message: "Failed", error: error.message });
  }
};
