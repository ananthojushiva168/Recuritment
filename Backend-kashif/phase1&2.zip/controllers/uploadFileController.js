const cloudinary = require("../Utils/cloudinary");
const User = require("../model/photoURL");

//! ------------ POST IMAGE FUNCTIONALITY -------------- >
const PostImage = async (req, res) => {
  try {
    const result = await cloudinary.uploader.upload(req.file.path);

    //? ------------ create instance of user ------------ >
    let user = new User({
      //   profile: {
      name: req.body.name,
      avatar: result.secure_url,
      cloudinary_id: result.public_id,
      //   },
    });

    //? ---- save user ---- >
    await user.save();
    res.json(user);
  } catch (error) {
    console.log(error);
  }
};

//! ------------ POST FILE FUNCTIONALITY -------------- >
const PostFile = async (req, res) => {
  try {
    const result = await cloudinary.uploader.upload(req.file.path);

    //! ------------ create instance of user ------------ >
    let userfile = new User({
      //   cv: {
      name: req.body.name,
      filecv: result.secure_url,
      cloudinary_id: result.public_id,
      //   },
    });

    //? ---- save user ---- >
    await userfile.save();
    res.json(userfile);
  } catch (error) {
    console.log(error);
  }
  console.log(req.file);
};

//! -------------- GET UPLOAD FILE FUNCTIONALITY ---------------- >
const GetUploadFile = async (req, res) => {
  try {
    const id = req.params.id;
    let user = await User.findById({ _id: id });
    res.json(user);
   
  } catch (error) {
    console.log(error);
  }
};

//! ---------------- UPDATE IMAGE FUNCTIONALITY ------------- >
const UpdateImage = async (req, res) => {
  try {
    let user = await User.findById(req.params.id);
    await cloudinary.uploader.destroy(user.cloudinary_id);
    const result = await cloudinary.uploader.upload(req.file.path);

    const data = {
      name: req.body.name || user.name,
      avatar: result.secure_url || user.avatar,
      cloudinary_id: result.public_id || user.cloudinary_id,
    };
    user = await User.findByIdAndUpdate(req.params.id, data, {
      new: true,
    });

    res.json(user);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
    console.log(error);
  }
};

//! ---------------- UPDATE FILE FUNCTIONALITY ------------- >
const updatefile = async (req, res) => {
  try {
    let user = await User.findById(req.params.id);
    await cloudinary.uploader.destroy(user.cloudinary_id);
    const result = await cloudinary.uploader.upload(req.file.path);

    const data = {
      name: req.body.name || user.name,
      filecv: result.secure_url || user.filecv,
      cloudinary_id: result.public_id || user.cloudinary_id,
    };
    user = await User.findByIdAndUpdate(req.params.id, data, {
      new: true,
    });

    res.json(user)


  } catch (error) {
    console.log(error)
  }
}

//! ------------------ DELETE UPLOAD FILES BY ID ---------------->
const DeleteFile = async (req, res) => {
  try {
    //? ----------- Find user by id -->
    let user = await User.findById(req.params.id);
    
    //? ---------- Delete image from cloudinary -->
    await cloudinary.uploader.destroy(user.cloudinary_id);

    //? ---------- Delete user from db -->
    await user.remove();
    res.json(user);
  } catch (err) {
    console.log(err);
  }
};









module.exports = {
  PostImage,
  PostFile,
  GetUploadFile,
  UpdateImage,
  DeleteFile,
  updatefile,

};
