import { Employer } from "../models/employerModel.js";

//@ Employer Update
export const update = async (req, res) => {
  try {
    //updating employer
    console.log(req.user)

    const user = await Employer.findById(req.user._id);
    user.designation = req.body.designation;
    user.location = req.body.location;
    user.website = req.body.website;
    user.description = req.body.description;

    await user.save();
    res.status(201).json({ message: true });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Failed", error: error.message });
  }
};




//update and delete employee
//@update employee details
export const update = async (req, res) => {
  try {
    //updating employee
    const user = await Employee.findByIdAndUpdate(
      { _id: req.user._id },
      req.body,
      { new: true }
    );
    res.status(201).json({ message: true, user });
    //updating education details
     const education = await Employee.updateMany(
      { _id: req.user._id },
      {$set:{
        education.university = req.education.university,

      }}
     
    );
    res.status(202).json({ message: true, education }); 

   
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Failed", error: error.message });
  }
};





//@DELETE EMPLOYEE
export const delProfile = async(req , res) =>{
  try{
    //deleting employee profile

    const user = await Employee.findByIdAndRemove
    ({_id:req.user._id});

    res
    .status(200)
    .cookie("token", null, { expires: new Date(Date.now()) })
    .json({ success: true, message: "Logout and Account has Deleted Successfully" });
  }catch(error){
    return res
    .status(500)
    .json({ success: false, message: "Failed", error: error.message });
  }
}




//UPDATE AND DELETE EMPLOYER
//@ Employer Update
export const update = async (req, res) => {
  try {
    //updating employer


    const user = await Employer.findByIdAndUpdate(
      {_id:req.user._id},
      req.body,
      {multi:true}
      );
    // user.designation = req.body.designation;
    // user.location = req.body.location;
    // user.website = req.body.website;
    // user.description = req.body.description;

 
    res.status(201).json({ message: true, user });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Failed", error: error.message });
  }
};


//@DELETE EMPLOYER
export const delProfile = async(req , res) =>{
  try{
    //deleting employee profile

    const user = await Employer.findByIdAndRemove
    ({_id:req.user._id});

    res
    .status(200)
    .cookie("token", null, { expires: new Date(Date.now()) })
    .json({ success: true, message: "Logout and Account has Deleted Successfully" });
  }catch(error){
    return res
    .status(500)
    .json({ success: false, message: "Failed", error: error.message });
  }
}




//employee routes
router.patch("/updateEmployee", isAuthenticated, update);
router.delete("/deleteprofile",isAuthenticated,delProfile);



//employer routes
router.patch("/updateprofile", isAuthenticated, update);
router.delete("/deleteProfile",isAuthenticated, delProfile);


import { register,login, logout, update , delProfile } from "../controllers/employeeController.js";
