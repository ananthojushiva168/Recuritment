import { Employer } from "../models/employerModel.js";
import { sendMail } from "../utils/sendMail.js";
import otpgenerator from "otp-generator";
import { sendToken } from "../utils/sendToken.js";

//? Employer Signup controller
export const register = async (req, res) => {
  try {
    const { company_name, full_name, email, password } = req.body;

    let employer = await Employer.findOne({ email });

    //* Checking user has already exists or not with same Email
    if (employer) {
      return res.status(400).json({
        success: false,
        message: `Employer already exists with ${email}`,
      });
    }

    //@ Generating OTP
    const otp = otpgenerator.generate(6, {
      digits: true,
      upperCaseAlphabets: false,
      lowerCaseAlphabets: false,
      specialChars: false,
    });

    //* Creating new User
    employer = await Employer.create({
      company_name,
      full_name,
      email,
      password,
      otp,
      otp_expiry: new Date(Date.now() + process.env.OTP_EXPIRE * 60 * 1000),
    });

    let subject = ["first Verify your account", "Email Verification code"];
    let html = employer;
    await sendMail(email, subject, html);

    res.status(200).json({
      success: true,
      message: `email_varified : ${employer.email_verified}`,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
    });
  }
};

//@EMPLOYER LOGIN
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res
        .status(400)
        .json({ success: false, message: "Please enter all fields" });
    }

    //* Checking if user has verified or not
    const isVerified = await Employer.findOne({ email });
    console.log(isVerified.email_verified);
    if (!isVerified.email_verified) {
      return res.status(400).json({
        success: false,
        message: "Your Email has not been verified, first verify your email id",
      });
    }
    // * Checking if user has registered or not
    const employer = await Employer.findOne({ email }).select("+password");
    if (!employer) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid Email or Password" });
    }
    const isMatch = await employer.comparePassword(password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid Email or Password" });
    }
    sendToken(res, employer, 200, "Logged in successfully");
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

//@ Employer Logout
export const logout = async (req, res) => {
  try {
    return res
      .status(200)
      .cookie("token", null, { expires: new Date(Date.now()) })
      .json({ success: true, message: "Logout Successfully" });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Failed", error: error.message });
  }
};

//@ Employer Update
export const update = async (req, res) => {
  try {
    //updating employer


    const user = await Employer.findByIdAndUpdate(
      {_id:req.user._id},
      req.body,
      {multi:true}
      );
    // user.designation = req.body.designation;
    // user.location = req.body.location;
    // user.website = req.body.website;
    // user.description = req.body.description;
     
 
    res.status(201).json({ message: true, user });
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Failed", error: error.message });
  }
};


//@ Employeer image upload
export const PostImage = async (req, res) => {
  try {
    const result = await cloudinary.v2.uploader.upload(req.file.path);
    const user = await Employer.findById(req.user._id);
    let image = await user.avatar.public_id;

    if (result) {
      if (!image) {
        user.avatar.public_id = result.public_id;
        user.avatar.url = result.secure_url;
      } else {
        await cloudinary.v2.uploader.destroy(user.avatar.public_id);

        user.avatar.public_id = result.public_id;
        user.avatar.url = result.secure_url;
      }
    } else {
      res.status(400).json({ success: false, message: "Error Uploading" });
    }

    //? ---- save user ---- >
    await user.save();
    res.status(200).json(user.avatar);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "500-Failed",
      error: error.message,
    });
  }
};

//@DELETE EMPLOYER
export const delProfile = async(req , res) =>{
  try{
    //deleting employee profile

    const user = await Employer.findByIdAndRemove
    ({_id:req.user._id});

    res
    .status(200)
    .cookie("token", null, { expires: new Date(Date.now()) })
    .json({ success: true, message: "Logout and Account has Deleted Successfully" });
  }catch(error){
    return res
    .status(500)
    .json({ success: false, message: "Failed", error: error.message });
  }
}

