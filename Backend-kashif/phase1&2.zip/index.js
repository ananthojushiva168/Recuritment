import dotenv from "dotenv";
dotenv.config();

import Express from "express";
import colors from "colors";
import cors from "cors";
const app = Express();
import cloudinary from "cloudinary";
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
})
//@ Database connection and Port
import { DBconnection } from "./config/DBconnection.js";
DBconnection();

// const port = process.env.PORT || 7000;
let port = process.env.PORT || 8080;
const v1api = "/api/v1";

//@ express middlewares
app.use(Express.json());
app.use(Express.urlencoded({ extended: true }));
app.use(cors());
app.use(cookieParser())

//? Importing Employee Router
import employeeRoutes from "./routes/employeeRoutes.js";

//@ Using Employee Routes
app.use(v1api+"/employee", employeeRoutes);

//? Importing Employer Router
import employerRoutes from "./routes/employerRoutes.js";
import cookieParser from "cookie-parser";

//@ Using Employer Routes
app.use(v1api+"/employer", employerRoutes);



app.listen(port, () => {
  console.log(`Server is running on port ${port}`.cyan.bold);
});
