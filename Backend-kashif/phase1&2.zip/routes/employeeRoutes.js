import express from "express";
import {
  register,
  login,
  logout,
  uploadEdu,
  update,
  delProfile,
  uploadexp,
  updateExp,
  deleteExperince,
  deleteEducation,
  updateMyProfile,
  updateSkills,
  deleteSkills,
  PostImage,
  PostFile,
  GetEmployee,
  DeleteImage,
  DeleteFile,
  bannerImage,
  DeleteBanner
} from "../controllers/employeeController.js";
import { isAuthenticated } from "../middlewares/Authenticated.js";
import {uploadImage, uploadFile, uploadBanner} from "../utils/multer.js";

const router = express.Router();

//? Authentication Routes
router.post("/register", register);
router.post("/login", login);
router.get("/logout", logout);
router.get("/getemployee", isAuthenticated,GetEmployee);
router.patch("/updateEmployee", isAuthenticated, updateMyProfile);
router.post("/uploadEmpEdu", isAuthenticated, uploadEdu);
router.patch("/updateEmployeeEdu/:id", isAuthenticated, update);
router.post("/uploadEmployeeExp", isAuthenticated, uploadexp);
router.patch("/updateEmployeeExp/:id", isAuthenticated, updateExp);
router.delete("/deleteExp/:id", isAuthenticated, deleteExperince);
router.delete("/deleteEdu/:id", isAuthenticated, deleteEducation);
router.patch("/updateskills", isAuthenticated, updateSkills);
router.delete("/deleteskills/:item", isAuthenticated, deleteSkills );

router.post("/image",isAuthenticated, uploadImage.single('image'), PostImage);
router.post("/file", isAuthenticated,uploadFile.single("file"), PostFile);
router.post("/bannerImage", isAuthenticated,uploadBanner.single("image"), bannerImage);
router.patch("/deleteimage", isAuthenticated, DeleteImage);
router.patch("/deletefile", isAuthenticated, DeleteFile);
router.patch("/deletebanner", isAuthenticated, DeleteBanner);

// router.put('/file/:id', isAuthenticated, uploadFile.single('file'), updatefile);

// router.get("/:id", isAuthenticated, GetUploadFile);


// router.patch("/ex_desc/:id", isAuthenticated, ex_desc);
router.delete("/deleteprofile", isAuthenticated, delProfile);

export default router;
