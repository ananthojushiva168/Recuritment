import express from "express";
import { register, login, logout, update , delProfile, PostImage } from "../controllers/employerController.js";
import { isAuthenticated } from "../middlewares/Authenticated.js";
// import { update } from "../controllers/updateEmployer.js";
import {uploadImage} from "../utils/multer.js";
const router = express.Router();

//? Authentication Routes
router.post("/register", register);
router.post("/login", login);
router.get("/logout", logout);
router.patch("/updateprofile", isAuthenticated, update,);
router.delete("/deleteProfile",isAuthenticated, delProfile);

router.post("/image",isAuthenticated, uploadImage.single('image'), PostImage);

export default router;
