const router = require("express").Router();
const { uploadImage, uploadFile } = require("../Utils/multer");
const {PostImage, PostFile, GetUploadFile, DeleteFile, UpdateImage, updatefile} = require('../controllers/uploadFileController');


//! ------------ POST IMAGE ROUTE ------------- >
router.post("/image", uploadImage.single('image'), PostImage);

//! ------------ POST FILE ROUTE -------------- >
router.post("/file", uploadFile.single("file"), PostFile);

//! -------------- GET UPLOAD FILE / IMAGE ROUTE---------------- >
router.get("/:id", GetUploadFile);

//! ----------- UPDATE IMAGE ROUTE ---------- >
router.patch("/:id", uploadImage.single("image"), UpdateImage);

//! ----------- UPDATE FILE ROUTE ---------- >
router.put('/:id', uploadFile.single('file'), updatefile)

//! --------------- DELETE FILE / IMAGE ROUTER------------- >
router.delete("/:id", DeleteFile);


module.exports = router;
